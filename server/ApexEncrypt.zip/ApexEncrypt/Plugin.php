<?php

namespace Plugin\ApexEncrypt;

use App\Services\Plugin\AbstractPlugin;
use App\Protocols\ClashMeta;

class Plugin extends AbstractPlugin
{
    public function boot(): void
    {
        $this->filter('client.subscribe.servers', function ($servers, $user, $request) {
            if (!filter_var($this->getConfig('enabled', true), FILTER_VALIDATE_BOOLEAN)) {
                return $servers;
            }

            $myFlag = strtolower(trim((string) $this->getConfig('flag', 'apex')));
            $reqFlag = $this->requestFlag($request);
            if ($myFlag === '' || $reqFlag === '' || strpos($reqFlag, $myFlag) === false) {
                return $servers;
            }

            $key = (string) $this->getConfig('encrypt_key', '');
            if ($key === '') {
                $this->intercept(response(
                    'ApexEncrypt: encrypt_key not configured.',
                    200
                )->header('content-type', 'text/plain; charset=utf-8'));
            }

            // 把客户端标识传进协议类。缺了这三个参数时 clientName / clientVersion
            // 都是 null，AbstractProtocol::filterServersByVersion() 里那些按客户端
            // 版本过滤节点的规则就失去版本维度（白名单仍生效，但「某传输方式需要
            // x.y.z 以上」这类判断会因拿不到版本而放行）。
            // clientName 固定给 'meta'：本插件产出的就是 ClashMeta 配置，让
            // protocolRequirements 里 meta 段的规则能正常命中。
            // 【2.5.0】补上面板自己那两步:「在订阅中展示订阅信息」(剩余流量 / 套餐到期 /
            // 距离重置)和「显示协议前缀」。它们在 ClientController::doSubscribe() 里排在本钩子
            // **之后**,而本插件在钩子里就把订阅渲染并截走了 —— 所以开了订阅加密的客户端一直
            // 看不到这几行,第三方客户端(走面板原流程)却有。
            $servers = $this->applyPanelDecorations($servers, $user);

            $protocol = new ClashMeta(
                $user,
                $servers,
                'meta',
                $this->clientVersion($reqFlag),
                $reqFlag
            );
            $rendered = $protocol->handle();
            [$body, $headers] = $this->extractBodyHeaders($rendered);

            $out = response($this->encrypt($body, $key));
            foreach ($headers as $hk => $hv) {
                $out->header($hk, $hv);
            }
            $this->intercept($out);
        }, self::PRIORITY);
    }

    /**
     * 排在最后执行(数字越大越晚,默认 20)。
     *
     * 本插件一进来就渲染 + 截走响应,排在它后面的同钩子插件永远没机会运行。往节点列表里
     * 加东西的插件(自定义信息行、节点过滤、账户异常提示……)都是默认优先级,必须让它们先跑完。
     */
    private const PRIORITY = 9999;

    /**
     * 调用面板核心的 setSubscribeInfoToServers() / addPrefixToServerName()。
     *
     * 这两个是 ClientController 的私有方法,没有扩展点,所以用反射直接调**面板自己的实现**
     * 而不是抄一份:文案、开关、重置日算法都跟着面板走,面板升级或二开改了也不用同步。
     * 任何一步出错(方法改名 / 签名变了)都原样返回 —— 少几行提示是小事,订阅接口不能炸。
     *
     * 账户异常(封禁 / 到期 / 流量用完)时不加:这时节点列表是「异常提示」类插件换上的
     * 提示节点,再叠上剩余流量几行只会把真正的提示挤下去。
     */
    private function applyPanelDecorations($servers, $user)
    {
        if (!is_array($servers) || !isset($servers[0]) || self::accountAbnormal($user)) {
            return $servers;
        }
        $class = '\\App\\Http\\Controllers\\V1\\Client\\ClientController';
        try {
            if (!class_exists($class)) {
                return $servers;
            }
            $controller = app($class);

            if (method_exists($controller, 'setSubscribeInfoToServers')) {
                $m = new \ReflectionMethod($controller, 'setSubscribeInfoToServers');
                $copy = $servers;
                $m->invokeArgs($controller, [&$copy, $user, 0]);
                if (is_array($copy) && isset($copy[0])) {
                    $servers = $copy;
                }
            }

            if (method_exists($controller, 'addPrefixToServerName')) {
                $m = new \ReflectionMethod($controller, 'addPrefixToServerName');
                $out = $m->invoke($controller, $servers);
                if (is_array($out) && isset($out[0])) {
                    $servers = $out;
                }
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning(
                '[apex_encrypt] 订阅信息 / 协议前缀未加上,订阅照常下发: ' . $e->getMessage()
            );
        }
        return $servers;
    }

    /** 封禁 / 到期 / 流量用完。$user 可能是模型也可能是数组,两种都按下标读。 */
    private static function accountAbnormal($user): bool
    {
        if ($user === null) {
            return false;
        }
        if (!empty($user['banned'])) {
            return true;
        }
        $expiredAt = $user['expired_at'] ?? null;
        if ($expiredAt !== null && (int) $expiredAt <= time()) {
            return true;
        }
        $total = (int) ($user['transfer_enable'] ?? 0);
        return $total > 0 && (int) ($user['u'] ?? 0) + (int) ($user['d'] ?? 0) >= $total;
    }

    private function requestFlag($request): string
    {
        $flag = $request->input('flag');
        if ($flag === null || $flag === '') {
            $flag = $request->header('User-Agent', '');
        }
        return strtolower((string) $flag);
    }

    /**
     * 从客户端标识里取版本号，取不到返回 null。
     *
     * 与 ClientController::getClientInfo() 保持同一套正则，避免两条下发路径
     * 对同一个 UA 解析出不同版本。形如 Apex/1.2.3、Apex 1.2、ApexVPN/v2 都能取到。
     */
    private function clientVersion(string $flag): ?string
    {
        if (preg_match('/[a-zA-Z0-9\-_]+[\/\s]+(v?[0-9]+(?:\.[0-9]+){0,2})/', $flag, $m)) {
            return preg_replace('/^v/', '', $m[1]);
        }
        if (preg_match('/\/v?(\d+(?:\.\d+){0,2})/', $flag, $m)) {
            return $m[1];
        }
        return null;
    }

    private function extractBodyHeaders($rendered): array
    {
        if (is_object($rendered)
            && method_exists($rendered, 'getContent')
            && isset($rendered->headers)) {
            $keep = [];
            foreach (['subscription-userinfo', 'profile-update-interval',
                      'content-disposition', 'content-type'] as $h) {
                $v = $rendered->headers->get($h);
                if ($v !== null && $v !== '') {
                    $keep[$h] = $v;
                }
            }
            return [(string) $rendered->getContent(), $keep];
        }
        return [(string) $rendered, []];
    }

    private function encrypt(string $content, string $key): string
    {
        $inner = base64_encode($content);
        $klen = strlen($key);
        $xor = '';
        for ($i = 0, $n = strlen($inner); $i < $n; $i++) {
            $xor .= chr(ord($inner[$i]) ^ ord($key[$i % $klen]));
        }
        return base64_encode($xor);
    }
}
