<?php

namespace Plugin\ApexEncrypt;

use App\Services\Plugin\AbstractPlugin;
use App\Protocols\ClashMeta;

class Plugin extends AbstractPlugin
{
    public function boot(): void
    {
        $this->filter('client.subscribe.servers', function ($servers, $user, $request) {
            if (!filter_var($this->getConfig('enabled', true), FILTER_VALIDATE_BOOLEAN)) {
                return $servers;
            }

            $myFlag = strtolower(trim((string) $this->getConfig('flag', 'apex')));
            $reqFlag = $this->requestFlag($request);
            if ($myFlag === '' || $reqFlag === '' || strpos($reqFlag, $myFlag) === false) {
                return $servers;
            }

            $key = (string) $this->getConfig('encrypt_key', '');
            if ($key === '') {
                $this->intercept(response(
                    'ApexEncrypt: encrypt_key not configured.',
                    200
                )->header('content-type', 'text/plain; charset=utf-8'));
            }

            // 把客户端标识传进协议类。缺了这三个参数时 clientName / clientVersion
            // 都是 null，AbstractProtocol::filterServersByVersion() 里那些按客户端
            // 版本过滤节点的规则就失去版本维度（白名单仍生效，但「某传输方式需要
            // x.y.z 以上」这类判断会因拿不到版本而放行）。
            // clientName 固定给 'meta'：本插件产出的就是 ClashMeta 配置，让
            // protocolRequirements 里 meta 段的规则能正常命中。
            $protocol = new ClashMeta(
                $user,
                $servers,
                'meta',
                $this->clientVersion($reqFlag),
                $reqFlag
            );
            $rendered = $protocol->handle();
            [$body, $headers] = $this->extractBodyHeaders($rendered);

            $out = response($this->encrypt($body, $key));
            foreach ($headers as $hk => $hv) {
                $out->header($hk, $hv);
            }
            $this->intercept($out);
        });
    }

    private function requestFlag($request): string
    {
        $flag = $request->input('flag');
        if ($flag === null || $flag === '') {
            $flag = $request->header('User-Agent', '');
        }
        return strtolower((string) $flag);
    }

    /**
     * 从客户端标识里取版本号，取不到返回 null。
     *
     * 与 ClientController::getClientInfo() 保持同一套正则，避免两条下发路径
     * 对同一个 UA 解析出不同版本。形如 Apex/1.2.3、Apex 1.2、ApexVPN/v2 都能取到。
     */
    private function clientVersion(string $flag): ?string
    {
        if (preg_match('/[a-zA-Z0-9\-_]+[\/\s]+(v?[0-9]+(?:\.[0-9]+){0,2})/', $flag, $m)) {
            return preg_replace('/^v/', '', $m[1]);
        }
        if (preg_match('/\/v?(\d+(?:\.\d+){0,2})/', $flag, $m)) {
            return $m[1];
        }
        return null;
    }

    private function extractBodyHeaders($rendered): array
    {
        if (is_object($rendered)
            && method_exists($rendered, 'getContent')
            && isset($rendered->headers)) {
            $keep = [];
            foreach (['subscription-userinfo', 'profile-update-interval',
                      'content-disposition', 'content-type'] as $h) {
                $v = $rendered->headers->get($h);
                if ($v !== null && $v !== '') {
                    $keep[$h] = $v;
                }
            }
            return [(string) $rendered->getContent(), $keep];
        }
        return [(string) $rendered, []];
    }

    private function encrypt(string $content, string $key): string
    {
        $inner = base64_encode($content);
        $klen = strlen($key);
        $xor = '';
        for ($i = 0, $n = strlen($inner); $i < $n; $i++) {
            $xor .= chr(ord($inner[$i]) ^ ord($key[$i % $klen]));
        }
        return base64_encode($xor);
    }
}
