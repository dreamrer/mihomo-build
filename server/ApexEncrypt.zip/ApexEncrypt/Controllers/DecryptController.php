<?php

namespace Plugin\ApexEncrypt\Controllers;

use App\Http\Controllers\Controller;
use App\Traits\HasPluginConfig;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

/**
 * 面板 API 路径解密控制器(GeneralEncryptionMiddleware 的"装进 xboard 插件"版)。
 *
 * 客户端(开了 mw_enabled 的包)把 /api/v1/* 藏进 <前缀>/<密文>.<伪装扩展名>
 * (默认 /assets/immutable/<密文>.json,前缀走后台 mw_path_prefix)。本控制器:
 *   1. XChaCha20-Poly1305 解密 → 还原真实后端路径(/sub 剥前缀走订阅、否则拼 API_PREFIX);
 *   2. 用还原后的路径构造子请求,经 app()->handle() 内部重放 → 走面板正常路由/中间件/鉴权;
 *   3. 任何失败(解密/越权/过期/重放/未启用)→ 与 nginx 完全一致的伪装 404。
 *
 * crypto 与客户端 EncryptMiddlewareCodec 逐字节一致(已 Dart↔PHP 交叉验证)。
 * 配置走后台 UI(HasPluginConfig 读 DB),不用 .env。
 */
class DecryptController extends Controller
{
    use HasPluginConfig;

    private const FORMAT_VERSION = 0x03;

    /**
     * 混淆前缀的默认值,与客户端的编译期默认值相同 —— 两边都不配就能直接跑通。
     *
     * ⚠️ **只认后台配的这一个前缀,没有任何兼容回退。**
     * 前缀在客户端是编译期烧死在二进制里的、改不了,所以一旦改了这里,所有**已经
     * 装在用户手机上**的包会立刻全部登录失败,表现是每个请求都返回伪装 404、
     * 面板日志里看不出任何异常。要改就必须同时打新包并让用户全部更新。
     */
    private const DEFAULT_PATH_PREFIX = '/assets/immutable';

    /** nginx 风格 404,逐字节对齐 GeneralEncryptionMiddleware 的 decoy。 */
    private const NOT_FOUND_HTML = "<html>\n<head><title>404 Not Found</title></head>\n<body>\n<center><h1>404 Not Found</h1></center>\n<hr><center>nginx</center>\n</body>\n</html>\n";

    private const CAMOUFLAGE_EXTS = [
        '.js', '.css', '.map', '.json', '.png', '.webp',
        '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff2', '.woff',
    ];

    /** HasPluginConfig 要求:返回本插件 code。 */
    protected function getPluginCode(): string
    {
        return 'apex_encrypt';
    }

    public function handle(Request $request, string $apexMwPath): Response
    {
        // 递归守卫:子请求重放时带此头,若又进到这里(理论不会)直接伪装 404。
        if ($request->headers->has('X-Apex-Mw-Replay')) {
            return $this->decoy();
        }
        if (!filter_var($this->getConfig('mw_enabled', false), FILTER_VALIDATE_BOOLEAN)) {
            return $this->notOurs();   // 没开混淆 → 交还面板,当这条路由不存在
        }

        // 路由是通配的(前缀已做成后台可配,静态路由文件拿不到 getConfig),
        // 所以前缀在这里比对。不是我们的路径 → 交还面板,**不能无脑 404**,
        // 否则会把面板自己所有未匹配的路由都吞掉。
        $path = '/' . ltrim($apexMwPath, '/');
        $prefix = $this->matchPrefix($path);
        if ($prefix === null) {
            return $this->notOurs();
        }
        $token = substr($path, strlen($prefix) + 1);

        $target = $this->resolve($token);
        if ($target === null) {
            return $this->decoy();
        }
        [$realPath, $query] = $target;

        // 用真实路径构造子请求,内部重放。保留方法/头(含 Authorization)/Cookie/Body。
        $uri = $realPath . ($query !== '' ? '?' . $query : '');
        $sub = Request::create(
            $uri,
            $request->getMethod(),
            // 非 GET 传原请求已解析好的表单 bag:Symfony create() 把第 3 个参数当
            // request bag,传 [] 会让 x-www-form-urlencoded 的表单字段整体丢失
            // (JSON 体不受影响,Laravel 从 content 读)。
            $request->getMethod() === 'GET' ? $this->parseQuery($query) : $request->request->all(),
            $request->cookies->all(),
            $request->files->all(),
            $request->server->all(),
            $request->getContent()
        );
        $sub->headers->replace($request->headers->all());
        $sub->headers->set('X-Apex-Mw-Replay', '1');
        $sub->server->set('REQUEST_URI', $uri);
        $sub->server->set('QUERY_STRING', $query);

        // 经完整 HTTP 内核重放 → 命中真实 api 路由 + 其鉴权中间件。子请求路径是
        // /api/v1/*,不匹配本前缀,不会递归。
        $response = app()->handle($sub);
        // 混淆路径下的响应一律禁缓存:面板本身不设 Cache-Control(裸头),而前面若挂
        // CDN,不少默认策略按扩展名缓存(.svg/.ico/.woff2/.webp 常在名单里),
        // 会把已解密的用户 API 响应缓存后发给别人。不赌 CDN 名单,出口钉死。
        $response->headers->set('Cache-Control', 'no-store, private');
        return $response;
    }

    /** 解密 + 还原真实后端路径。任何异常/越权 → null。返回 [realPath, query]。 */
    private function resolve(string $token): ?array
    {
        $token = ltrim($token, '/');
        if ($token === '') {
            return null;
        }
        $token = $this->stripCamouflageExt($token);

        $plain = $this->decrypt($token); // ['path','longLived'] | null
        if ($plain === null || !str_starts_with($plain['path'], '/')) {
            return null;
        }

        $p = $plain['path'];
        if (($h = strpos($p, '#')) !== false) {
            $p = substr($p, 0, $h);
        }
        $query = '';
        if (($q = strpos($p, '?')) !== false) {
            $query = substr($p, $q + 1);
            $p = substr($p, 0, $q);
        }
        if ($this->hasControl($p) || $this->hasControl($query) || str_contains($p, '..')) {
            return null;
        }

        // 与客户端写死同款 /sub(bot 向导不收集,客户端永远用默认)——不做成可配,防两端不一致。
        $subPrefix = '/sub';
        $isSub = $subPrefix !== '' && str_starts_with($p, $subPrefix . '/');

        if ($plain['longLived'] && !$isSub) {
            return null; // 长期票据只允许订阅
        }
        if ($isSub) {
            $real = substr($p, strlen($subPrefix));
            if (!$this->isSubAllowed($real)) {
                return null;
            }
            return [$real, $query]; // 订阅不拼 API_PREFIX
        }
        // 拼回 API 前缀。**必须与客户端的 apiPrefix 一致**:客户端加密前会把自己的
        // apiPrefix 剥掉(见 composeMiddlewarePlain),由这里拼回。而客户端那个值是
        // OSS 远程配置可覆盖的(config 里的 api_prefix),所以这里不能写死 ——
        // 运营者一改 OSS,解出来的后端路径就全错,表现是全站伪装 404 且无报错。
        return [$this->apiPrefix() . $p, $query];
    }

    /** XChaCha20-Poly1305 解密 + 解包 + 时间窗/防重放。返回 ['path','longLived'] | null。 */
    private function decrypt(string $token): ?array
    {
        $raw = $this->b64decode($token);
        if ($raw === null || strlen($raw) < 24 + 16) {
            return null;
        }
        $nonce = substr($raw, 0, 24);
        $body = substr($raw, 24);

        $inner = false;
        foreach ($this->keys() as $key) {
            $out = @sodium_crypto_aead_xchacha20poly1305_ietf_decrypt($body, '', $nonce, $key);
            if ($out !== false) {
                $inner = $out;
                break;
            }
        }
        if ($inner === false) {
            return null;
        }

        if (strlen($inner) < 3 || ord($inner[0]) !== self::FORMAT_VERSION) {
            return null;
        }
        $n = unpack('n', substr($inner, 1, 2))[1];
        if (3 + $n > strlen($inner)) {
            return null;
        }
        $bodyStr = substr($inner, 3, $n);

        $sep = strpos($bodyStr, '|');
        if ($sep === false) {
            return null;
        }
        $ts = substr($bodyStr, 0, $sep);
        $path = substr($bodyStr, $sep + 1);
        if ($path === '' || !preg_match('/^-?\d+$/', $ts)) {
            return null;
        }

        $sec = (int) $ts;
        if ($sec === 0) {
            return ['path' => $path, 'longLived' => true]; // 长期票据:跳过窗/重放
        }

        $window = (int) $this->getConfig('mw_timestamp_window', 300);
        if ($window <= 0) {
            $window = 300;
        }
        if (abs(time() - $sec) > $window) {
            return null; // 过期
        }
        $nonceKey = 'apexmw:nonce:' . bin2hex($nonce);
        if (!Cache::add($nonceKey, 1, $window)) {
            return null; // 重放
        }
        return ['path' => $path, 'longLived' => false];
    }

    private function keys(): array
    {
        $primary = (string) $this->getConfig('mw_aes_key', '');
        return $primary === '' ? [] : [hash('sha256', $primary, true)];
    }

    private function isSubAllowed(string $p): bool
    {
        // 自动认 xboard 两种内建订阅路由(运营不用配):
        //   ① /api/v1/client/subscribe(legacy API 订阅)
        //   ② /{subscribe_path}/{token}(短链)—— 读 xboard 后台 subscribe_path(默认 s → /s/)。
        if (str_starts_with($p, '/api/v1/client/subscribe')) {
            return true;
        }
        $short = '/' . trim((string) admin_setting('subscribe_path', 's'), '/') . '/';
        if (str_starts_with($p, $short)) {
            return true;
        }
        // 额外补充:运营手填的自定义订阅路径(逗号分隔),给"改过面板订阅路由/别的插件
        // 另开了订阅路径"这类场景。填的是**解密后、本面板真实存在的路径** —— 解密后是在
        // 本面板内部重放(app()->handle()),外部反代/独立订阅服务器的地址填这里无意义。
        foreach (array_filter(array_map('trim', explode(',', (string) $this->getConfig('mw_subscription_allowed_paths', '')))) as $a) {
            // 裸 '/' 会恒真 → 长期票据(不校时间窗/不查重放)可打到任意路由,
            // 故只认以 / 开头且有实际路径段的条目。
            if (strlen($a) > 1 && $a[0] === '/' && str_starts_with($p, $a)) {
                return true;
            }
        }
        return false;
    }

    private function stripCamouflageExt(string $s): string
    {
        foreach (self::CAMOUFLAGE_EXTS as $ext) {
            if (str_ends_with($s, $ext)) {
                return substr($s, 0, -strlen($ext));
            }
        }
        return $s;
    }

    private function hasControl(string $s): bool
    {
        for ($i = 0, $len = strlen($s); $i < $len; $i++) {
            $c = ord($s[$i]);
            if ($c < 0x20 || $c === 0x7f) {
                return true;
            }
        }
        return false;
    }

    private function b64decode(string $s): ?string
    {
        foreach ([
            SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING,
            SODIUM_BASE64_VARIANT_URLSAFE,
            SODIUM_BASE64_VARIANT_ORIGINAL_NO_PADDING,
            SODIUM_BASE64_VARIANT_ORIGINAL,
        ] as $v) {
            try {
                return sodium_base642bin($s, $v);
            } catch (\Throwable $e) {
            }
        }
        return null;
    }

    private function parseQuery(string $query): array
    {
        if ($query === '') {
            return [];
        }
        parse_str($query, $out);
        return $out;
    }

    /**
     * 归一化后台填的混淆前缀;判定为危险时返回 '' = 关闭路径混淆。
     *
     * 与 v2board 版 ApexMiddleware::pathPrefix() 和打包机器人的校验同一套判据 ——
     * 三处不一致就会出现"这边认那边不认"。
     * 留空 / 只有斜杠 / 撞面板自身路由段,一律 fail-safe 关闭而不是带病运行。
     */
    /**
     * 这条路径归不归我们管?归我们管返回命中的前缀,否则返回 null。
     *
     * **只比后台配的那一个前缀**,没有兼容回退:前缀两端必须完全一致。
     * 前缀为空(留空,或填了保留路径被判危险)时一律返回 null —— 等于关掉路径
     * 混淆、把请求原样交还面板,而不是把全站未匹配请求都吞掉。
     */
    private function matchPrefix(string $path): ?string
    {
        $prefix = $this->mwPathPrefix();
        if ($prefix === '') {
            return null;
        }
        return strpos($path, $prefix . '/') === 0 ? $prefix : null;
    }

    /** 解密后拼回真实路径用的 API 前缀。归一化成 '' 或 '/xxx'(无尾斜杠)。 */
    private function apiPrefix(): string
    {
        $p = trim((string) $this->getConfig('mw_api_prefix', '/api/v1'));
        $p = rtrim($p, '/');
        if ($p === '') {
            return '';   // 显式配成空 = 不拼前缀
        }
        return $p[0] === '/' ? $p : '/' . $p;
    }

    private function mwPathPrefix(): string
    {
        $p = trim((string) $this->getConfig('mw_path_prefix', self::DEFAULT_PATH_PREFIX));
        $p = '/' . trim($p, "/ \t\n\r\0\x0B");
        if ($p === '/' || $p === '') {
            return '';
        }
        // 默认值本身就落在 /assets 下,必须放行,否则"用默认值"这条路被自己堵死。
        if ($p === self::DEFAULT_PATH_PREFIX) {
            return $p;
        }
        $lower = strtolower($p);
        foreach (['/api', '/admin', '/theme', '/assets'] as $reserved) {
            if ($lower === $reserved || strpos($lower, $reserved . '/') === 0) {
                return '';
            }
        }
        return $p;
    }

    /**
     * 不是本插件该管的路径 → 抛 404 让 Laravel 按"路由不存在"处理。
     *
     * 与 decoy() 的区别很重要:decoy 是**伪装**404(给探测者看的,内容固定、
     * 不暴露任何信息);这里是**真的**不该由我们处理 —— 通配路由会兜住面板全部
     * 未匹配请求,若一律 decoy,面板自己的 404 页、静态资源、其它插件路由就全被
     * 我们吞了。
     */
    private function notOurs()
    {
        abort(404);
    }

    private function decoy(): Response
    {
        return new Response(self::NOT_FOUND_HTML, 404, [
            'Content-Type' => 'text/html',
            'Server' => 'nginx',
            'Cache-Control' => 'no-store, private',
        ]);
    }
}
