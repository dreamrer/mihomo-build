<?php
// 独立自测:不依赖 Xboard,用最小替身跑插件的订阅钩子。  php tests/run.php
// 守的是 2.5.0 修的问题:开了订阅加密的客户端看不到「剩余流量 / 套餐到期」,
// 也看不到别的插件往节点列表里加的行(本插件原来先于它们把订阅截走了)。

namespace App\Services\Plugin {
    class InterceptResponseException extends \Exception { public $response; }
    class HookManager {
        public static array $filters = [];
        public static function registerFilter(string $hook, callable $cb, int $priority = 20): void {
            self::$filters[$hook][$priority][] = $cb;
        }
        public static function filter(string $hook, $value, ...$args) {
            ksort(self::$filters[$hook]);
            foreach (self::$filters[$hook] as $cbs) foreach ($cbs as $cb) $value = $cb($value, ...$args);
            return $value;
        }
    }
    class AbstractPlugin {
        public array $config = [];
        public function getConfig(string $k, $default = null) { return $this->config[$k] ?? $default; }
        protected function filter(string $hook, callable $cb, int $priority = 20): void {
            HookManager::registerFilter($hook, $cb, $priority);
        }
        protected function intercept($response): void {
            $e = new InterceptResponseException(); $e->response = $response; throw $e;
        }
    }
}
namespace App\Protocols {
    class ClashMeta {
        public static array $lastServers = [];
        public function __construct(public $user, public $servers, ...$rest) { self::$lastServers = $servers; }
        public function handle() { return implode("\n", array_column($this->servers, 'name')); }
    }
}
namespace App\Http\Controllers\V1\Client {
    // 方法名、可见性、参数与 Xboard 核心一致(私有、按引用传 $servers)
    class ClientController {
        public static bool $showInfo = true;
        public static bool $showPrefix = false;
        public static bool $explode = false;
        private function setSubscribeInfoToServers(&$servers, $user, $rejectServerCount = 0) {
            if (self::$explode) throw new \RuntimeException('boom');
            if (!isset($servers[0]) || !self::$showInfo) return;
            array_unshift($servers, array_merge($servers[0], ['name' => '套餐到期：2030-01-01']));
            array_unshift($servers, array_merge($servers[0], ['name' => '剩余流量：10 GB']));
        }
        private function addPrefixToServerName(array $servers): array {
            if (!self::$showPrefix) return $servers;
            return array_map(fn($s) => array_merge($s, ['name' => '[vless]' . $s['name']]), $servers);
        }
    }
}
namespace Illuminate\Support\Facades { class Log { public static array $w = []; public static function warning($m) { self::$w[] = $m; } } }
namespace {
    class FakeResponse {
        public array $h = [];
        public function __construct(public string $body) {}
        public function header($k, $v) { $this->h[$k] = $v; return $this; }
    }
    function response($body = '', $status = 200) { return new FakeResponse((string) $body); }
    function app($class) { return new $class(); }
    class Req {
        public function __construct(private string $flag) {}
        public function input($k) { return $k === 'flag' ? $this->flag : null; }
        public function header($k, $d = '') { return $d; }
    }

    require __DIR__ . '/../Plugin.php';

    use App\Services\Plugin\HookManager;
    use App\Services\Plugin\InterceptResponseException;
    use App\Protocols\ClashMeta;
    use App\Http\Controllers\V1\Client\ClientController;

    $fails = 0;
    function check(string $name, bool $ok): void {
        global $fails;
        echo ($ok ? "  ok   " : "  FAIL ") . $name . "\n";
        if (!$ok) $fails++;
    }
    function decrypt(string $body, string $key): string {
        $xor = base64_decode($body); $out = '';
        for ($i = 0, $n = strlen($xor); $i < $n; $i++) $out .= chr(ord($xor[$i]) ^ ord($key[$i % strlen($key)]));
        return base64_decode($out);
    }
    /** 跑一次订阅钩子;被本插件截走返回 [响应, 渲染用的节点名],否则返回 [null, 钩子返回的节点名] */
    function run(array $servers, array $user, string $flag): array {
        ClashMeta::$lastServers = [];
        try {
            $out = HookManager::filter('client.subscribe.servers', $servers, $user, new Req($flag));
            return [null, array_column($out, 'name')];
        } catch (InterceptResponseException $e) {
            return [$e->response, array_column(ClashMeta::$lastServers, 'name')];
        }
    }

    // 另一个插件(默认优先级 20,**后注册**)往节点列表顶上加一行 —— 模拟自定义信息行插件
    $plugin = new \Plugin\ApexEncrypt\Plugin();
    $plugin->config = ['flag' => 'mybrand', 'encrypt_key' => 'k3y-for-test'];
    $plugin->boot();
    HookManager::registerFilter('client.subscribe.servers', function ($servers) {
        array_unshift($servers, array_merge($servers[0], ['name' => '官网：example.com']));
        return $servers;
    });

    $nodes = [['name' => 'HK-01', 'type' => 'vless'], ['name' => 'JP-01', 'type' => 'vless']];
    $ok = ['banned' => 0, 'expired_at' => time() + 86400, 'transfer_enable' => 100, 'u' => 1, 'd' => 1];

    echo "正常账户 + 自家 flag\n";
    [$resp, $names] = run($nodes, $ok, 'mybrand');
    check('被本插件截走并加密', $resp !== null);
    check('面板的订阅信息在最上面,其后是别的插件加的行,再是节点',
        $names === ['剩余流量：10 GB', '套餐到期：2030-01-01', '官网：example.com', 'HK-01', 'JP-01']);
    check('密文能用同一把密钥解回渲染结果', $resp && decrypt($resp->body, 'k3y-for-test') === implode("\n", $names));

    echo "面板开了协议前缀\n";
    ClientController::$showPrefix = true;
    [, $names] = run($nodes, $ok, 'MyBrand/v5.0.0');
    check('前缀也加上了', $names[3] === '[vless]HK-01');
    ClientController::$showPrefix = false;

    echo "面板没开「展示订阅信息」\n";
    ClientController::$showInfo = false;
    [, $names] = run($nodes, $ok, 'mybrand');
    check('不加订阅信息,别的插件的行仍在', $names === ['官网：example.com', 'HK-01', 'JP-01']);
    ClientController::$showInfo = true;

    echo "账户异常(到期 / 流量用完 / 封禁)\n";
    foreach ([['expired_at' => time() - 10], ['u' => 60, 'd' => 60], ['banned' => 1]] as $bad) {
        [, $names] = run($nodes, array_merge($ok, $bad), 'mybrand');
        check('不叠加订阅信息: ' . json_encode($bad), !in_array('剩余流量：10 GB', $names, true));
    }

    echo "面板方法抛异常\n";
    ClientController::$explode = true;
    [$resp, $names] = run($nodes, $ok, 'mybrand');
    check('订阅照常加密下发,只是少了那几行', $resp !== null && $names === ['官网：example.com', 'HK-01', 'JP-01']);
    ClientController::$explode = false;

    echo "别的客户端(flag 不匹配)\n";
    [$resp, $names] = run($nodes, $ok, 'clash-verge/v2.0');
    check('不截、不加密,交回面板原流程', $resp === null && $names === ['官网：example.com', 'HK-01', 'JP-01']);

    echo $fails === 0 ? "\n全部通过\n" : "\n有 {$fails} 项失败\n";
    exit($fails === 0 ? 0 : 1);
}
