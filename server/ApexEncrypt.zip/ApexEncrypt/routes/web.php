<?php

/**
 * 路径混淆解密路由。xboard 插件路由由 PluginManager 自动加载(见 loadRoutes)。
 *
 * 用**通配路由**而不是写死前缀:前缀已做成后台可配(config.json 的
 * mw_path_prefix),而本文件是静态加载的、拿不到 getConfig,只能全捕获、
 * 由 DecryptController 自己比对前缀。
 *
 * ⚠️ 但通配必须**收窄到伪装扩展名结尾**,不能真的 `.*`:
 *   裸 `.*` 会吃掉面板**所有**未匹配的请求 —— 包括方法不匹配的情况
 *   (实测:`GET /api/v1/passport/auth/login` 本该是 405,被这条路由接走后
 *   变成 404),也包括其它插件后注册的 fallback 路由。
 *   加密后的路径必然以伪装扩展名结尾(客户端 APEX_MW_EXT,默认 .json),
 *   所以按扩展名收窄既不漏自己的请求,又把误伤面收到最小。
 *
 * 这个清单必须与 DecryptController::CAMOUFLAGE_EXTS **保持一致**:
 * 这里决定"路由收不收",那里决定"收了之后怎么剥"。少一个 = 该扩展名的
 * 包发出来的请求根本进不到控制器,表现是登录全 404 且查不出原因。
 *
 * 不匹配的请求原样交还面板正常路由,不影响任何现有功能;
 * 路径混淆没开(mw_enabled=false)时控制器也会交还。
 */

use Illuminate\Support\Facades\Route;

Route::any('{apexMwPath}', 'DecryptController@handle')
    ->where('apexMwPath', '.*\.(?:js|css|map|json|png|webp|jpg|jpeg|gif|svg|ico|woff2|woff)')
    ->name('apex.mw.catchall');
